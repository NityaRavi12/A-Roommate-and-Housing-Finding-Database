use roomNest;

-- Checks if the login details entered are correct
drop function if exists login_details_check;
delimiter //
Create function login_details_check (username_arg varchar(50), password_arg varchar(50), typeOfUser varchar(50))
Returns int
Deterministic
reads sql data
Begin
declare i int;
CASE typeOfUser
	when 'landlord' then
		select count(*) from landlord where username = username_arg and password = password_arg into i;
	when 'broker' then
		select count(*) from broker where username = username_arg and password = password_arg into i;
	when 'student' then
		select count(*) from student where username = username_arg and password = password_arg into i;
	else
		select 0 into i;
end case;
return i;
end //
delimiter ;

-- checks if username is already taken
drop function if exists userNameCheck;
delimiter //
Create function userNameCheck (username_arg varchar(50))
Returns int
Deterministic
reads sql data
Begin
declare i int;
select count(*) from (SELECT DISTINCT
    username
FROM
    landlord 
UNION SELECT DISTINCT
    username
FROM
    broker 
UNION SELECT DISTINCT
    username
FROM
    student as all_usernames) xyz where username = username_arg INTO i;
return i;
end //
delimiter ;

-- select userNameCheck("lalitkishrestudetn");



-- drop function if exists student_exists;
-- delimiter //
-- Create function student_exists (student_id_arg int)
-- Returns int
-- Deterministic
-- reads sql data
-- Begin
-- declare i int;
-- select count(*) from student where student_id = student_id_arg INTO i;
-- return i;
-- end //
-- delimiter ;