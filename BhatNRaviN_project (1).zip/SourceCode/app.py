import brokerOperations
import connectToDB
import landlordOperations
import menu
import studentDetails
import studentOperations
import userLogin

if __name__ == "__main__":

    # Getting the connection to the DB
    conn = connectToDB.connection()
    cursor = conn.cursor()

    # Login the user
    while True:
        userStatus = int(userLogin.userstatus())
        usertype = 0
        if userStatus == 1:
            userid, usertype = userLogin.newuser(cursor, conn)
            break
        elif userStatus == 2:
            userid, usertype = userLogin.returninguser(cursor)
            break
        else:
            # Loop back and ask for a valid choice
            print("Enter a valid choice")

    # Display the menu of the options available
    while True:
        # New student
        if usertype == 1 and userStatus == 1:
            choice = menu.chooseStudentMenu()
            studentOperations.handleChoice(choice, userid, cursor, conn)
            # newStudentId = studentDetails.enterDetails(username, name, userpwd, cursor)
            # studentDetails.enterpreferences(newStudentId)
        # Existing student
        if usertype == 1 and userStatus == 2:
            choice = menu.chooseStudentMenu()
            studentOperations.handleChoice(choice, userid, cursor, conn)
        # Landlord menu
        # For new user:
        elif usertype == 2 and userStatus == 1:
            # create a house to assign to this new landlord
            landlordOperations.handleChoice(userid, 1, cursor, conn)
            userStatus = 2
        # Broker menu
        elif usertype == 2 and userStatus == 2:
            choice = menu.chooseLandlordMenu()
            landlordOperations.handleChoice(userid, choice, cursor, conn)
        # Broker menu
        elif usertype == 3:
            choice = menu.chooseBrokerMenu()
            brokerOperations.handleChoice(userid, choice, cursor)
        else:
            print("Enter a valid choice")
