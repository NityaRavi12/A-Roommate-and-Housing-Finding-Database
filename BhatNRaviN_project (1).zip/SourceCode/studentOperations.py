import studentDetails


def handleChoice(choice, studentid, cursor, conn):
    if choice == 1 or choice == 2:
        if choice == 1:
            # Show all the houses that are near the university the student in attending
            cursor.execute(f"call roomNest.show_all_houses({studentid})")
            results = cursor.fetchall()
            if not results:
                print("Sorry no houses near your university currently available! Try again tomorrow.")
                return
        else:
            # Show only houses that match student's preference
            # Based on the roommates currently living there
            # Call the function that filters based on the current
            # student ID sent to it
            cursor.execute(f"call roomNest.filtered_houses({studentid})")
            results = cursor.fetchall()
            if not results:
                print("Sorry no houses with residents that match your preferences!\n Try again tomorrow,"
                      "or edit your preferences")
                return
        print("~~~~~~~~ Available Houses: ~~~~~~~~")
        listOfHouses = []
        for result in results:
            print(f"House ID: {result[0]}")
            print(f"House unit: {result[1]}")
            print(f"Street: {result[2]}")
            print(f"Bedrooms: {result[3]}")
            print(f"Floor: {result[4]}")
            print(f"Area: {result[5]} sq. ft.")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            listOfHouses.append(result[0])
        print("Do you want to get the details of any of the listed houses?")
        while True:
            try:
                houseid = int(input("Enter the house ID: "))
            except:
                print("Please enter a valid input house ID")
                continue
            if houseid not in listOfHouses:
                print("Please enter a valid house ID")
            else:
                break

        # Call procedure to show all the spots of the house that aren't occupied
        cursor.execute(f"call roomNest.show_spot_details({houseid})")
        results = cursor.fetchall()
        if not results:
            print("Sorry no spot data currently available! Try again tomorrow.")
            return
        print("~~~~~~~~ Available Spots: ~~~~~~~~")
        listOfSpots = []
        for result in results:
            print(f"Spot ID: {result[0]}")
            print(f"Rent: ${result[1]}")
            print(f"Attached Bathroom: {result[2]}")
            print(f"AC Installed: {result[3]}")
            print(f"Fan Installed: {result[4]}")
            print(f"Closet: {result[5]}")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            listOfSpots.append(result[0])
        print("Do you want to get the details of any of the current residents in this house?")
        while True:
            try:
                spotid = int(input("Enter the spot ID: "))
            except:
                print("Please enter a valid input")
                continue
            if spotid not in listOfSpots:
                print("Please enter a valid spot ID")
            else:
                break
        # View roomates that are currently occupying that house
        cursor.execute(f"call roomNest.show_roommate_details({spotid})")
        results = cursor.fetchall()
        if not results:
            print("Sorry no roommate data currently available! Try again tomorrow.")
            return
        print("~~~~ Potential roommate details: ~~~~")
        for result in results:
            print(f"Prefers to eat: {result[0]} food")
            print(f"Is from: {result[1]}")
            print(f"Speaks: {result[2]}")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Do you want the contact of the landlord of this house?\n1. Yes\n2. Not now")
        while True:
            choice = input("Enter your choice: ")
            if choice != "1" and choice != "2":
                print("Please enter a valid choice")
                continue
            if choice == "2":
                return
            else:
                cursor.execute(f"call roomNest.get_landlord({spotid})")
                results = cursor.fetchall()
                if not results:
                    print("Sorry no landlord data currently available!")
                    return
                print("~~~~~~~~ Landlord Details: ~~~~~~~~")
                for result in results:
                    print(f"Name: {result[0]}")
                    print(f"Phone number: {result[1]}")
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                return

    elif choice == 3:
        # Allow the student to edit his housing preferences
        studentDetails.enterpreferences(studentid, cursor, 1, conn)
        # Call the procedure that allows an update
        # to the preferences table
    else:
        print("Thanks for using the application!")
        exit(0)
