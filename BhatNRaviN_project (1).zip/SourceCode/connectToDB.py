import getpass

import lib


# Establish a connection to the DB
def connection():
    while True:
        dbUname = input("Enter the SQL username: ")
        # dbPwd = input("Enter the SQL password: ")
        dbPwd = getpass.getpass("Enter the SQL password: ")
        # dbUname = "root"
        # dbPwd = "secret"
        try:
            conn = lib.pymysql.connect(
                host='localhost',
                user=dbUname,
                password=dbPwd,
                db='roomNest')
            print("Sucessfully connected to the Database!\n")
            return conn
        except:
            print("Invalid credentials. Try again\n")
