def createRoom(bedrooms, cursor, conn):
    print("Enter the details of the rooms in the house :\n")
    # Take the details per bedroom
    spots = 0
    for i in range(bedrooms):
        print(f"{i} room details have been entered. {bedrooms - i} details yet to be entered")
        while True:
            try:
                spots += int(input("How many students can this room accommodate? "))
                break
            except:
                print("Please enter a valid number")
                continue

        while True:
            bathattached = input("Does this room have a bathroom attached? (Y/N): ")
            if bathattached != "Y" and bathattached != "N":
                print("Please enter a valid option")
            else:
                if bathattached == "Y":
                    bathattached = True
                else:
                    bathattached = False
                break
        while True:
            ac = input("Does this room have any ACs installed? (Y/N): ")
            if ac != "Y" and ac != "N":
                print("Please enter a valid option")
            else:
                if ac == "Y":
                    ac = True
                else:
                    ac = False
                break
        while True:
            fan = input("Does this room have any fans installed? (Y/N): ")
            if fan != "Y" and fan != "N":
                print("Please enter a valid option")
            else:
                if fan == "Y":
                    fan = True
                else:
                    fan = False
                break
        while True:
            closet = input("Does this room have a closet? (Y/N): ")
            if closet != "Y" and closet != "N":
                print("Please enter a valid option")
            else:
                if closet == "Y":
                    closet = True
                else:
                    closet = False
                break

        # Procedure to get the latest house
        cursor.execute("select house_inserted_id()")
        house_id = cursor.fetchone()[0]

        # Procedure to create a room in a house
        cursor.execute(f"call roomNest.new_room ({bathattached}, {ac} ,"
                       f" {fan},{closet},{spots},"
                       f" {house_id})")
        conn.commit()

    return spots
