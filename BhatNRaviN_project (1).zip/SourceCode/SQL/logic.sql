use roomNest;
drop function if exists login_details_check;
delimiter //
Create function login_details_check (username_arg varchar(50), password_arg varchar(50), typeOfUser varchar(50))
Returns int
Deterministic
reads sql data
Begin
declare i int;
CASE typeOfUser
	when 'landlord' then
		select count(*) from landlord where username = username_arg and password = password_arg into i;
	when 'broker' then
		select count(*) from broker where username = username_arg and password = password_arg into i;
	when 'student' then
		select count(*) from student where username = username_arg and password = password_arg into i;
	else
		select 0 into i;
end case;
return i;
end //
delimiter ;

-- next procedure takes in student_id, food pref, smoker, country pref, lang_preference, gender pref(m or f), age(int) insert statement into 
drop procedure if exists update_preferences;
delimiter //
create procedure update_preferences(
student_id int, food_pref varchar(15), smoker_bit boolean,
 country_pref varchar(30), lang_pref varchar(15), budget int,
 gender_pref varchar(5))
begin
update roomNest.preferences 
set id = student_id, food_preference = food_pref, smoker = smoker_bit,
 country_preference = country_pref, language_preference = lang_pref, budget = budget,
 gender_preference = gender_pref
where id = student_id;
end //
delimiter ;


-- All unoccupied spots near the uni
-- Takes in student ID
drop procedure if exists show_all_houses;
delimiter //
create procedure show_all_houses(student_id_arg INT)
begin 
SELECT DISTINCT
    H.UNIT,
    H.STREET,
    H.NUM_BEDS,
    H.FLOORS,
    H.AREA_SFT
FROM
    HOUSE H
        JOIN
    ROOM R ON R.HOUSE_ID = H.ID
        JOIN
    SPOT ON SPOT.ROOM_ID = R.ID
		JOIN
    PROXIMAL_UNIVERSITIES PU ON H.ID = PU.HOUSE
		LEFT JOIN
	TENANT T ON T.SPOT_ID = SPOT.ID
WHERE
    UNIVERSITY = (SELECT 
            university
        FROM
            STUDENT S
        WHERE
            s.id = student_id_arg)
	AND T.STUDENT_ID IS NULL;
end //
delimiter ;
call show_all_houses(2);


-- All unoccupied spots near in the house
-- Takes in house unit
drop procedure if exists show_spot_details;
delimiter //
create procedure show_spot_details(house_unit_arg INT)
begin 
SELECT S.ID as SpotID, RENT, BATH_ATTACHED, AC_AVAILABLE, FAN_AVAILABLE, CLOSET_AVAILABLE
FROM SPOT S
JOIN ROOM R ON S.ROOM_ID = R.ID
JOIN HOUSE H ON H.ID = R.HOUSE_ID
LEFT JOIN TENANT T ON T.SPOT_ID = S.ID
WHERE H.UNIT = house_unit_arg
AND T.SPOT_ID IS NULL;
end //
delimiter ;
call show_spot_details(12);



-- Get details about current roomates
-- takes in spot id
drop procedure if exists SHOW_ROOMATE_DETAILS;
delimiter //
create procedure SHOW_ROOMATE_DETAILS(SPOT_ID_ARG INT)
begin 
SELECT UNIVERSITY, COUNTRY, LANGUAGE
FROM
    HOUSE H
        JOIN
    ROOM R ON H.ID = R.HOUSE_ID
        JOIN
    SPOT S ON S.ROOM_ID = R.ID
        LEFT JOIN
    TENANT T ON T.SPOT_ID = S.ID
        LEFT JOIN
    STUDENT ST ON ST.ID = S.ID
WHERE
    H.ID = (SELECT DISTINCT
            H.ID
        FROM
            HOUSE H
                JOIN
            ROOM R ON H.ID = R.HOUSE_ID
                JOIN
            SPOT S ON S.ROOM_ID = R.ID
        WHERE
            S.ID = SPOT_ID_ARG)
	AND UNIVERSITY IS NOT NULL;
end //
delimiter ;
call SHOW_ROOMATE_DETAILS(1);

-- View landlord details for a spot
-- takes in the spot ID
drop procedure if exists get_landlord;
delimiter //
create procedure get_landlord(SPOT_ID_ARG INT)
begin 
SELECT L.NAME, L.PHONE
FROM SPOT S
JOIN ROOM R ON S.ROOM_ID = R.ID
JOIN HOUSE H ON H.ID = R.HOUSE_ID
JOIN LANDLORD L ON L.ID = H.LANDLORD
WHERE S.ID = 12;
end //
delimiter ;
call get_landlord(11);








SELECT 
    *
FROM
    SPOT;

-- All current tenants in a house
drop procedure if exists show_all_spotDetails;
delimiter //
-- noinspection SqlNoDataSourceInspection
create procedure show_all_tenants(house_id_arg INT)
begin 
SELECT Spot.ID as SPOT_ID,
SPOT.RENT AS RENT
FROM TENANT T
JOIN SPOT ON SPOT.ID = T.SPOT_ID
JOIN ROOM ON ROOM.ID = SPOT.ROOM_ID
WHERE HOUSE_ID = house_id_arg;
end //
delimiter ;
call show_all_tenants(1);
