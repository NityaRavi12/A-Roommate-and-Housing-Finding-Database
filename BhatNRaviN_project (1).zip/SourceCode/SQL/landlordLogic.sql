-- Create a new landlord
drop procedure if exists create_new_landlord; 

delimiter //
create procedure create_new_landlord(
    name_arg varchar(30), phone varchar(10), username varchar(30),
     password_arg varchar(30))
begin
insert into landlord(name,phone,username,password) values (name_arg,phone,username,password_arg);
end //
delimiter ;
-- call create_new_landlord("landlord", "1234567890", "llord", "123pwd");
