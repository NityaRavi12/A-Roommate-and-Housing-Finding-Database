drop database if exists roomNest;

create database roomNest;
use roomNest;

CREATE TABLE Landlord (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(30) NOT NULL,
    phone VARCHAR(10) NOT NULL,
    username VARCHAR(100) NOT NULL,
    password VARCHAR(25) NOT NULL
);

CREATE TABLE Broker (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(30) NOT NULL,
    phone CHAR(10) NOT NULL,
    username VARCHAR(100) NOT NULL,
    password VARCHAR(25) NOT NULL
);

CREATE TABLE House (
    id INT PRIMARY KEY AUTO_INCREMENT,
    street VARCHAR(30) NOT NULL,
    unit VARCHAR(5) NOT NULL,
    city VARCHAR(20) NOT NULL,
    state VARCHAR(2) NOT NULL,
    pin INT NOT NULL,
    floors INT NOT NULL DEFAULT 0,
    num_baths INT NOT NULL DEFAULT 0,
    heating BOOLEAN DEFAULT FALSE,
    area_sft INT NOT NULL,
    num_beds INT DEFAULT 1,
    landlord INT DEFAULT 0,
    CONSTRAINT FOREIGN KEY (landlord)
        REFERENCES Landlord (id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE Proximal_Universities (
	house INT,
    university VARCHAR(100),
    CONSTRAINT FOREIGN KEY (house)
        REFERENCES House (id) on update cascade on delete cascade
);


CREATE TABLE Room (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bath_attached BOOLEAN DEFAULT FALSE,
    ac_available BOOLEAN DEFAULT FALSE,
    fan_available BOOLEAN DEFAULT FALSE,
    closet_available BOOLEAN DEFAULT FALSE,
    spot_quantity INT DEFAULT 1,
    house_id INT DEFAULT 0,
    CONSTRAINT FOREIGN KEY (house_id)
        REFERENCES House (id)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Spot (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rent INT NOT NULL DEFAULT 1,
    room_id INT NOT NULL DEFAULT 0,
    CONSTRAINT FOREIGN KEY (room_id)
        REFERENCES Room (id)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- letting it stay as {Mandatory, OR} to define tenant as someone with spot_id and homeseeker with no spot_id
CREATE TABLE Student (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    gender VARCHAR(6),
    age INT NOT NULL,
    university VARCHAR(100) NOT NULL,
    country VARCHAR(30) NOT NULL,
    language VARCHAR(15),
    username VARCHAR(100) NOT NULL,
    password VARCHAR(25) NOT NULL
);

CREATE TABLE Preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    food_preference VARCHAR(15) NOT NULL,
    smoker BOOLEAN DEFAULT FALSE,
    country_preference VARCHAR(30) NOT NULL,
    language_preference VARCHAR(15),
    budget INT NOT NULL,
    gender_preference VARCHAR(5),
    CONSTRAINT FOREIGN KEY (id)
        REFERENCES Student (id)
        ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE TABLE Tenant (
    spot_id INT,
    student_id INT,
    CONSTRAINT FOREIGN KEY (student_id)
        REFERENCES Student (id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT FOREIGN KEY (spot_id)
        REFERENCES Spot (id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE Homeseeker (
    student_id INT ,
    CONSTRAINT FOREIGN KEY (student_id)
        REFERENCES Student (id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE leases (
    landlord_id INT NOT NULL,
    broker_id INT NOT NULL,
    house_id INT NOT NULL,
    student_id INT NOT NULL,
    CONSTRAINT FOREIGN KEY (landlord_id)
        REFERENCES Landlord (id),
    CONSTRAINT FOREIGN KEY (broker_id)
        REFERENCES Broker (id) on delete cascade on update cascade,
    CONSTRAINT FOREIGN KEY (house_id)
        REFERENCES House (id) on delete cascade on update cascade,
	CONSTRAINT FOREIGN KEY (student_id)
		REFERENCES Student(id) on delete cascade on update cascade
);