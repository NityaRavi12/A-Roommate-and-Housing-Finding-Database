use roomNest;

-- checks if username of the student exists
drop function if exists userNameCheck_student;
delimiter //
Create function userNameCheck_student (username_arg varchar(50))
Returns int
Deterministic
reads sql data
Begin
declare i int;
select count(*) from (SELECT DISTINCT
    username
FROM
    student) xyz where username = username_arg INTO i;
return i;
end //
delimiter ;

-- get student id when student username is given
drop procedure if exists getStudentId;
delimiter //
Create procedure getStudentId (username_arg varchar(50))
Begin
select id from student where username = username_arg;
end //
delimiter ;

call roomNest.getStudentId('mayisagoodtime');




-- checks if username of the broker exists
drop function if exists userNameCheck_broker;
delimiter //
Create function userNameCheck_broker (username_arg varchar(50))
Returns int
Deterministic
reads sql data
Begin
declare i int;
select count(*) from (SELECT DISTINCT
    username
FROM
    broker) xyz where username = username_arg INTO i;
return i;
end //
delimiter ;

-- get broker id when broker username is given
drop procedure if exists getBrokerId;
delimiter //
Create procedure getBrokerId (username_arg varchar(50))
Begin
select id from broker where username = username_arg;
end //
delimiter ;

-- checks if house exists
drop function if exists check_house;
delimiter //
Create function check_house (house_id_arg int)
Returns int
Deterministic
reads sql data
Begin
declare i int;
select count(*) from (SELECT DISTINCT
    id
FROM
    house) xyz where id = house_id_arg INTO i;
return i;
end //
delimiter ;

SELECT CHECK_HOUSE(20);


-- given a landlord id, broker id, student id, create the lease
SELECT 
    *
FROM
    leases;
drop procedure if exists create_lease_table;
delimiter //
create procedure create_lease_table(landlord_id_arg int, broker_id_arg int, student_id int, house_id_arg int)
begin
insert into leases values(landlord_id_arg, broker_id_arg, student_id, house_id_arg);
end //
delimiter ;

-- procedure to view all leases for 1 broker
drop procedure if exists view_leases;
delimiter //
create procedure view_leases(broker_id_arg int)
begin
select landlord.name as landlord_name, student.name as student_name, house.unit as house_unit, house.street, house.id as house_id
from leases 
JOIN house on house.id = leases.house_id
JOIN landlord on landlord.id = leases.landlord_id
JOIN student on student.id = leases.student_id
JOIN broker on broker.id = leases.broker_id
where broker_id = broker_id_arg;
end //
delimiter ;

call view_leases(1);
