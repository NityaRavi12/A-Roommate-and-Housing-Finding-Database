use roomNest;

select * from landlord;
insert into landlord values (1,"Lalit Kishore", "8576938897", "lalitkishore", "password");
insert into landlord values (2,"Dev Bhartra", "8567932289", "devbhartra", "Password@12");
insert into landlord values (3,"Ryan Jacobs", "4895789902", "jacobs.ryan123", "12password!12");
insert into landlord values (4,"Neehar Satti", "8674327781", "satti.neehar123", "password!@#$");
insert into landlord values (5,"Tom Cruise", "7864321123", "tom.cruise1234", "12@password!");
insert into landlord values (6,"Reetikesh Patel", "6784321189", "patel.reet", "tigon!@#$%pass");
insert into landlord values (7,"Kevin Goulhard", "8291075581", "kevingoulhard123", "password12");
insert into landlord values (8,"Amy schumer", "123456789", "schumeramy12", "passmeup");
insert into landlord values (9,"Alexandra Kaine", "5674321189", "kaineispain", "passmein");
insert into landlord values (10,"Karen", "6784231189", "karen", "tigon");


select * from broker;
insert into broker values (1, "Kevin", "8576938897", "kevin122", "password");
insert into broker values (2, "Bryan", "8567932289", "br12yan", "Password@12");
insert into broker values (3, "Cosner", "4895789902", "cosnerstuart123", "12password!12");

select * from house;
insert into house values(1, "Beechglen street", 1, "Boston", "MA", 02119, 1, 1, true, 900, 5, 1);
insert into house values(2, "Boylston street", 12, "Boston", "MA", 02129, 5, 2, true, 600, 3, 2);
insert into house values(3, "Beacon Street", 42, "Boston", "MA", 02129, 1, 1, true, 1600, 6, 3);
insert into house values(4, "Baker street", 47, "Boston", "MA", 02129, 2, 2, true, 500, 2, 4);
insert into house values(5, "Malcolm X Blvd", 3, "Boston", "MA", 02129, 3, 1, true, 1000, 4, 10);
insert into house values(6, "Seaport", 2, "Boston", "MA", 02129, 3, 2, true, 880, 3, 6);
insert into house values(7, "Park Drive", 8, "Boston", "MA", 02129, 3, 1, true, 900, 3, 7);
insert into house values(8, "Tremont street", 4, "Boston", "MA", 02129, 1, 2, true, 450, 2, 9);
insert into house values(9, "Burlington street", 151, "Boston", "MA", 02129, 1, 3, true, 1000, 4, 5);
insert into house values(10, "Sewall street", 7, "Boston", "MA", 02129, 2, 3, true, 980, 4, 8);


select * from Proximal_Universities;
insert into proximal_universities values(1,'Northeastern University');
insert into proximal_universities values(2,'Boston University');
insert into proximal_universities values(3,'Boston University');
insert into proximal_universities values(4,'MIT');
insert into proximal_universities values(5,'Northeastern University');
insert into proximal_universities values(6,'Boston University');
insert into proximal_universities values(7,'Boston University');
insert into proximal_universities values(8,'MIT');
insert into proximal_universities values(9,'MIT');
insert into proximal_universities values(10,'Boston University');

select * from room;
insert into room values(1,true,false,false,true,4,1);
insert into room values(2,true,false,true,true,1,1);
insert into room values(3,false,true,true,true,2,1);
insert into room values(4,false,true,true,true,3,1);
insert into room values(5,false,false,false,true,1,2);
insert into room values(6,false,false,true,true,1,2);
insert into room values(7,false,true,true,true,1,2);
insert into room values(8,false,true,true,true,2,2);
insert into room values(9,false,FALSE,true,true,2,3);
insert into room values(10,false,FALSE,true,true,1,3);
insert into room values(11,false,FALSE,true,true,2,4);
insert into room values(12,false,FALSE,true,true,2,4);
insert into room values(13,false,FALSE,true,true,1,5);
insert into room values(14,false,FALSE,true,true,2,5);
insert into room values(15,false,FALSE,true,true,3,6);
insert into room values(16,false,FALSE,true,true,3,6);
insert into room values(17,false,FALSE,true,true,1,7);
insert into room values(18,false,FALSE,true,true,2,7);
insert into room values(19,false,FALSE,true,true,1,8);
insert into room values(20,false,FALSE,true,true,2,8);
insert into room values(21,false,FALSE,true,true,1,9);
insert into room values(22,false,FALSE,true,true,2,9);
insert into room values(23,false,FALSE,true,true,1,10);
insert into room values(24,false,FALSE,true,true,2,10);

select * from spot;
insert into spot values(1,500,1);
insert into spot values(2,200,1);
insert into spot values(3,100,1);
insert into spot values(4,300,1);
insert into spot values(5,250,2);
insert into spot values(6,500,3);
insert into spot values(7,200,3);
insert into spot values(8,100,4);
insert into spot values(9,300,4);
insert into spot values(10,450,5);
insert into spot values(11,500,5);
insert into spot values(12,200,6);
insert into spot values(13,100,7);
insert into spot values(14,300,8);
insert into spot values(15,250,8);
insert into spot values(16,250,8);
insert into spot values(17,500,9);
insert into spot values(18,500,9);
insert into spot values(19,350,10);
insert into spot values(20,350,10);
insert into spot values(21,350,10);
insert into spot values(22,250,11);
insert into spot values(23,250,11);
insert into spot values(24,250,12);
insert into spot values(25,250,12);
insert into spot values(26,250,13);
insert into spot values(27,250,14);
insert into spot values(28,250,14);
insert into spot values(29,250,15);
insert into spot values(30,250,15);
insert into spot values(31,250,15);
insert into spot values(32,250,16);
insert into spot values(33,250,16);
insert into spot values(34,250,16);
insert into spot values(35,250,17);
insert into spot values(36,250,18);
insert into spot values(37,250,18);
insert into spot values(38,250,19);
insert into spot values(39,250,20);
insert into spot values(40,250,20);
insert into spot values(41,250,21);
insert into spot values(42,250,22);
insert into spot values(43,250,22);
insert into spot values(44,250,23);
insert into spot values(45,250,24);
insert into spot values(46,250,24);


select * from student;
insert into student values(1,"Lalit","M",23,"Northeastern University","India","Telugu",'lalitkishorestudetn','12345678');
insert into student values(2,"May","F",24,"Boston University","Italy","English",'mayisagoodtime','may12345678');
insert into student values(3,"Tom","M",19,"Northeastern University", "South America","Spanish",'tommcgallaghan','tommygun12');
insert into student values(4,"Ariana","F",21,"Boston University", "USA","English",'arianaventi','arianisnotapopidol');
insert into student values(5,"Riya","F",21,"Boston University", "USA","English",'arianaventi1','arianisnotapopidol');
insert into student values(6,"Reno","F",21,"Boston University", "USA","English",'arianaventi2','arianisnotsdfapopidol');
insert into student values(7,"Dinakar","M",21,"Boston University", "USA","English",'arianaventi3','arianisnodsftapopidol');
insert into student values(8,"Nehanth","M",21,"Northeastern University", "India","English",'nehanth','2222wdwdwd');
insert into student values(9,"Suhas","M",21,"Northeastern University", "India","English",'suhas','d23d232d23');
insert into student values(10,"Diwakar","M",21,"Northeastern University", "India","English",'diwakar','ddd3332');
insert into student values(11,"Mohith","M",21,"Northeastern University", "India","English",'mohit','arianisnotapoddd3pidol');
insert into student values(12,"Mohan","M",23,"MIT", "India","English",'mohan1','mohan123');


select * from preferences;
insert into preferences values(1,'nv',false,'USA','Hindi',850,'m');
insert into preferences values(2,'v',true,'Spain','Spanish',500,'f');
insert into preferences values(3,'np',false,'USA','Italian',1150,'m');
insert into preferences values(4,'nv',true,'India','English',700,'m');
insert into preferences values(5,'nv',true,'India','English',700,'m');
insert into preferences values(6,'nv',true,'USA','Spanish',700,'f');
insert into preferences values(7,'nv',true,'India','English',700,'np');
insert into preferences values(8,'nv',false,'India','English',700,'f');
insert into preferences values(9,'nv',false,'India','English',700,'m');
insert into preferences values(10,'nv',false,'India','English',700,'np');
insert into preferences values(11,'nv',false,'India','English',700,'f');



select * from tenant;
insert into tenant values(6,1);
insert into tenant values(7,2);
insert into tenant values(27,8);
insert into tenant values(28,9);
insert into tenant values(31,10);
insert into tenant values(32,11);



select * from homeseeker;
insert into homeseeker values(3);
insert into homeseeker values(4);
insert into homeseeker values(5);
insert into homeseeker values(6);
insert into homeseeker values(7);


select * from leases;
insert into leases values (1,1,1,1);
insert into leases values(1,3,3,1);
insert into leases values(2,3,2,2);
select * from landlord;