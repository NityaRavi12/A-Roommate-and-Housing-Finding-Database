SELECT 
    *
FROM
    student;
SELECT 
    *
FROM
    tenant;
SELECT 
    *
FROM
    preferences;
SELECT 
    *
FROM
    landlord;
SELECT 
    *
FROM
    house;
DELETE FROM house 
WHERE
    id = 4;
SELECT 
    *
FROM
    room;
SELECT 
    *
FROM
    spot;
DELETE FROM house 
WHERE
    id IN (3);
DELETE FROM landlord 
WHERE
    id = 15;
SELECT 
    *
FROM
    leases;
select * from tenant;
DELETE FROM leases 
WHERE
    broker_id = 3;
SELECT 
    *
FROM
    broker;
SELECT 
    *
FROM
    Proximal_Universities;
SELECT 
    *
FROM
    student;

insert into student values (12, "test", "M", 24, "MIT", "USA", "English", "test", "12345678");

SELECT 
    S.ID AS SpotID,
    RENT,
    BATH_ATTACHED,
    AC_AVAILABLE,
    FAN_AVAILABLE,
    CLOSET_AVAILABLE
FROM
    SPOT S
        JOIN
    ROOM R ON S.ROOM_ID = R.ID
        JOIN
    HOUSE H ON H.ID = R.HOUSE_ID
        LEFT JOIN
    TENANT T ON T.SPOT_ID = S.ID
WHERE
    H.ID = 7 AND T.SPOT_ID IS NULL;

SELECT 
    *
FROM
    spot;

SELECT 
    university, COUNT(name) AS students
FROM
    student
GROUP BY university;


select * from spot where room_id in (15, 16);
select * from tenant where spot_id in (29,30,31,32,33,34);

select * from preferences where id in (4, 10,11);

SELECT DISTINCT
    H.ID, H.UNIT, H.STREET, H.NUM_BEDS, H.FLOORS, H.AREA_SFT
FROM
    spot s
        JOIN
    room r ON s.room_id = r.id
        JOIN
    house h ON h.id = r.house_id
        JOIN
    tenant t ON t.spot_id = s.id
        JOIN
    preferences p ON p.id = t.student_id
WHERE
    h.id IN (SELECT DISTINCT
            H.ID AS house_id
        FROM
            HOUSE H
                JOIN
            ROOM R ON R.HOUSE_ID = H.ID
                JOIN
            SPOT ON SPOT.ROOM_ID = R.ID
                JOIN
            PROXIMAL_UNIVERSITIES PU ON H.ID = PU.HOUSE
                LEFT JOIN
            TENANT T ON T.SPOT_ID = SPOT.ID
        WHERE
            UNIVERSITY IN (SELECT 
                    university
                FROM
                    STUDENT S
                WHERE
                    s.id = 4)
                AND T.STUDENT_ID IS NULL)
        AND food_preference IN ((SELECT 
            food_preference
        FROM
            preferences
        WHERE
            id = 4), "np")
        AND country_preference IN ((SELECT 
            country_preference
        FROM
            preferences
        WHERE
            id = 4), "np")
        AND language_preference IN ((SELECT 
            language_preference
        FROM
            preferences
        WHERE
            id = 4), "np")
        AND gender_preference IN ((SELECT 
            gender_preference
        FROM
            preferences
        WHERE
            id = 4), "np");
  

SELECT 
    *
FROM
    preferences;
    
SELECT 
    food_preference
FROM
    preferences
WHERE
    id = 3;
    
SELECT 
    *
FROM
    preferences
WHERE
    id = 2;
    
select * from homeseeker;
select * from preferences where id = 7;
select * from house where id = 6;
select * from room where house_id IN (6);
select * from spot where room_id IN (15,16);
select * from tenant where spot_id IN (29,30,31,32,33,34);
select * from preferences where id in (10,11);

SELECT * FROM PREFERENCES;

SELECT P.FOOD_PREFERENCE, P.COUNTRY_PREFERENCE, P.LANGUAGE_PREFERENCE
FROM
    HOUSE H
        JOIN
    ROOM R ON H.ID = R.HOUSE_ID
        JOIN
    SPOT S ON S.ROOM_ID = R.ID
        LEFT JOIN
    TENANT T ON T.SPOT_ID = S.ID
        LEFT JOIN
    STUDENT ST ON ST.ID = S.ID
		JOIN
	PREFERENCES P ON P.ID = T.STUDENT_ID
WHERE
    H.ID = (SELECT DISTINCT
            H.ID
        FROM
            HOUSE H
                JOIN
            ROOM R ON H.ID = R.HOUSE_ID
                JOIN
            SPOT S ON S.ROOM_ID = R.ID
        WHERE
            S.ID = 29)
	-- AND UNIVERSITY IS NOT NULL
    ;
    
SELECT DISTINCT
            H.ID
        FROM
            HOUSE H
                JOIN
            ROOM R ON H.ID = R.HOUSE_ID
                JOIN
            SPOT S ON S.ROOM_ID = R.ID
        WHERE
            S.ID = 29;