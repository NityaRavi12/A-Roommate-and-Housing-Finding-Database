use roomNest;

-- insert into room table
drop procedure if exists new_room;
delimiter //
create procedure new_room(
bath_attached BOOLEAN, ac_available BOOLEAN, fan_available BOOLEAN, closet_available BOOLEAN, spot_quantity INT,
    house_id_arg int)
begin
insert into room (bath_attached,ac_available,fan_available,closet_available,spot_quantity,house_id) values (bath_attached, ac_available, fan_available, closet_available, spot_quantity, house_id_arg);
end //
delimiter ;
-- call new_house("Heath St", 2, "Quincy", "MA", 02232, 2, 2, False, 500, 3, 2);

select * from room;