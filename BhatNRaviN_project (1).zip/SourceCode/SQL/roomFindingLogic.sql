use roomNest;

-- All unoccupied spots near the uni
-- Takes in student ID
drop procedure if exists show_all_houses;
delimiter //
create procedure show_all_houses(student_id_arg INT)
begin 
SELECT DISTINCT
	H.ID,
    H.UNIT,
    H.STREET,
    H.NUM_BEDS,
    H.FLOORS,
    H.AREA_SFT
FROM
    HOUSE H
        JOIN
    ROOM R ON R.HOUSE_ID = H.ID
        JOIN
    SPOT ON SPOT.ROOM_ID = R.ID
		JOIN
    PROXIMAL_UNIVERSITIES PU ON H.ID = PU.HOUSE
		LEFT JOIN
	TENANT T ON T.SPOT_ID = SPOT.ID
WHERE
    UNIVERSITY = (SELECT 
            university
        FROM
            STUDENT S
        WHERE
            s.id = student_id_arg)
	AND T.STUDENT_ID IS NULL;
end //
delimiter ;
call show_all_houses(2);
select * from house;


-- All unoccupied spots near in the house
-- Takes in house unit
drop procedure if exists show_spot_details;
delimiter //
create procedure show_spot_details(house_id_arg INT)
begin 
SELECT S.ID as SpotID, RENT, BATH_ATTACHED, AC_AVAILABLE, FAN_AVAILABLE, CLOSET_AVAILABLE
FROM SPOT S
JOIN ROOM R ON S.ROOM_ID = R.ID
JOIN HOUSE H ON H.ID = R.HOUSE_ID
LEFT JOIN TENANT T ON T.SPOT_ID = S.ID
WHERE H.ID = house_id_arg
AND T.SPOT_ID IS NULL;
end //
delimiter ;
call show_spot_details(2);



-- Get details about current roomates
-- takes in spot id
drop procedure if exists SHOW_ROOMMATE_DETAILS;
delimiter //
create procedure SHOW_ROOMMATE_DETAILS(SPOT_ID_ARG INT)
begin 
SELECT P.FOOD_PREFERENCE, P.COUNTRY_PREFERENCE, P.LANGUAGE_PREFERENCE
FROM
    HOUSE H
        JOIN
    ROOM R ON H.ID = R.HOUSE_ID
        JOIN
    SPOT S ON S.ROOM_ID = R.ID
        LEFT JOIN
    TENANT T ON T.SPOT_ID = S.ID
        LEFT JOIN
    STUDENT ST ON ST.ID = S.ID
		JOIN
	PREFERENCES P ON P.ID = T.STUDENT_ID
WHERE
    H.ID = (SELECT DISTINCT
            H.ID
        FROM
            HOUSE H
                JOIN
            ROOM R ON H.ID = R.HOUSE_ID
                JOIN
            SPOT S ON S.ROOM_ID = R.ID
        WHERE
            S.ID = SPOT_ID_ARG)
	-- AND UNIVERSITY IS NOT NULL
    ;
end //
delimiter ;
call SHOW_ROOMMATE_DETAILS(35);

-- View landlord details for a spot
-- takes in the spot ID
drop procedure if exists get_landlord;
delimiter //
create procedure get_landlord(SPOT_ID_ARG INT)
begin 
SELECT L.NAME, L.PHONE
FROM SPOT S
JOIN ROOM R ON S.ROOM_ID = R.ID
JOIN HOUSE H ON H.ID = R.HOUSE_ID
JOIN LANDLORD L ON L.ID = H.LANDLORD
WHERE S.ID = 12;
end //
delimiter ;
call get_landlord(11);




SELECT 
    *
FROM
    SPOT;

-- All current tenants in a house
drop procedure if exists show_all_tenants;
delimiter //
create procedure show_all_tenants(house_id_arg INT)
begin 
SELECT Spot.ID as SPOT_ID,
SPOT.RENT AS RENT
FROM TENANT T
JOIN SPOT ON SPOT.ID = T.SPOT_ID
JOIN ROOM ON ROOM.ID = SPOT.ROOM_ID
WHERE HOUSE_ID = house_id_arg;
end //
delimiter ;
call show_all_tenants(1);

-- procedure to show all houses, which have an available spot
-- whose current residents, have the same preferences as the student searching
-- for the house
drop procedure if exists filtered_houses;
delimiter //
create procedure filtered_houses(student_id_arg INT)
begin 
SELECT DISTINCT
    H.ID, H.UNIT, H.STREET, H.NUM_BEDS, H.FLOORS, H.AREA_SFT
FROM
    spot s
        JOIN
    room r ON s.room_id = r.id
        JOIN
    house h ON h.id = r.house_id
        JOIN
    tenant t ON t.spot_id = s.id
        JOIN
    preferences p ON p.id = t.student_id
WHERE
    h.id IN (SELECT DISTINCT
            H.ID AS house_id
        FROM
            HOUSE H
                JOIN
            ROOM R ON R.HOUSE_ID = H.ID
                JOIN
            SPOT ON SPOT.ROOM_ID = R.ID
                JOIN
            PROXIMAL_UNIVERSITIES PU ON H.ID = PU.HOUSE
                LEFT JOIN
            TENANT T ON T.SPOT_ID = SPOT.ID
        WHERE
            UNIVERSITY IN (SELECT 
                    university
                FROM
                    STUDENT S
                WHERE
                    s.id = student_id_arg)
                AND T.STUDENT_ID IS NULL)
        AND food_preference IN ((SELECT 
            food_preference
        FROM
            preferences
        WHERE
            id = student_id_arg), "np")
        AND country_preference IN ((SELECT 
            country_preference
        FROM
            preferences
        WHERE
            id = student_id_arg), "np")
        AND language_preference IN ((SELECT 
            language_preference
        FROM
            preferences
        WHERE
            id = student_id_arg), "np")
        AND gender_preference IN ((SELECT 
            gender_preference
        FROM
            preferences
        WHERE
            id = student_id_arg), "np");
end //
delimiter ;

