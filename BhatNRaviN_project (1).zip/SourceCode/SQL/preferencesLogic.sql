use roomNest;

-- Set preferences for a new student
drop procedure if exists set_preferences;
SELECT 
    *
FROM
    preferences;
delimiter //
create procedure set_preferences(
student_id int, food_preference varchar(15), smoker bit,
 country_preference varchar(30), language_preference varchar(15),
 budget int, gender_preference varchar(5))
begin
insert into preferences values (student_id, food_preference, smoker, country_preference, language_preference, budget, gender_preference);
insert into homeseeker values (student_id);
end //
delimiter ;

-- call set_preferences(5, "v", False, "USA", "English", 1000, "m");

-- next procedure takes in student_id, food pref, smoker, country pref, lang_preference, gender pref(m or f), age(int) insert statement into 
drop procedure if exists update_preferences;
delimiter //
create procedure update_preferences(
student_id int, food_pref varchar(15), smoker_bit boolean,
 country_pref varchar(30), lang_pref varchar(15), budget int,
 gender_pref varchar(5))
begin
update roomNest.preferences 
set food_preference = food_pref, smoker = smoker_bit,
 country_preference = country_pref, language_preference = lang_pref, budget = budget,
 gender_preference = gender_pref
where id = student_id;
end //
delimiter ;
call update_preferences(5, "v", False, "Abc", "Anc", 900, "f");
