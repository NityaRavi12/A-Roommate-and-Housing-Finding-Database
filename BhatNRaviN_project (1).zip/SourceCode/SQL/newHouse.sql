use roomNest;

-- insert into house table
drop procedure if exists new_house;
delimiter //
create procedure new_house(
street varchar(30), unit_no VARCHAR(10), city varchar(20), state varchar(2),
 pin int, floor int, num_baths int, heating boolean,
 area_sft int, num_bed int, landlord_id int)
begin
insert into house (street,unit,city,state,pin,floors,num_baths,heating,area_sft,num_beds,landlord) values(street, unit_no, city, state, pin, floor, num_baths, heating, area_sft, num_bed , landlord_id);
end //
delimiter ;

-- call new_house("Heath St", 2, "Quincy", "MA", 02232, 2, 2, False, 500, 3, 2);