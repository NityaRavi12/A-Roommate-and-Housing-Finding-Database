use roomNest;

-- Create a new house
drop procedure if exists new_house;
delimiter //
create procedure new_house(
street varchar(30), unit_no int, city varchar(20), state varchar(2),
 pin int, floor int, num_baths int, heating boolean,
 area_sft int, num_bed int, landlord_id int)
begin
insert into house (street,unit,city,state,pin,floors,num_baths,heating,area_sft,num_beds,landlord) values(street, unit_no, city, state, pin, floor, num_baths, heating, area_sft, num_bed , landlord_id);
end //
delimiter ;
-- call new_house("Heath St", 2, "Quincy", "MA", 02232, 2, 2, False, 500, 3, 2);

-- drop a house given house_id
drop procedure if exists delete_house;
delimiter //
create procedure delete_house(house_id_arg int)
begin
delete from house where house.id = house_id_arg;
end //
delimiter ;
-- call delete_house(3);

SELECT 
    *
FROM
    house;
    
-- View all the houses that belong to a landlord    
drop procedure if exists view_houses;
delimiter //
create procedure view_houses(landlord_id_arg int)
begin
select house.id, house.street, house.unit from house
join landlord on house.landlord = landlord.id
where landlord.id = landlord_id_arg;
end //
delimiter ;
call view_houses(2);