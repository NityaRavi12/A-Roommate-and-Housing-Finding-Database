-- Create a new landlord
drop procedure if exists create_new_broker; 

delimiter //
create procedure create_new_broker(
    name_arg varchar(30), phone varchar(10), username varchar(30),
     password_arg varchar(30))
begin
insert into broker(name,phone,username,password) values (name_arg,phone,username,password_arg);
end //
delimiter ;

call create_new_broker("broker", "brokher", "1234567890", "123pwd");

select * from broker;