-- insert a new student login to student table and after this another moethod for pref table and homeseeker table
drop procedure if exists new_student;
delimiter //
create procedure new_student(
name_arg varchar(50), gender varchar(6), age int, university varchar(100),
 country varchar(30), language varchar(15), username varchar(100), password_student varchar(50))
begin
declare student_id_get int;
insert into student(
name,gender,age,university,country,language,username,password) values (
name_arg, gender, age, university, country, language, username, password_student);
end //
delimiter ;
select * from student;
-- call new_student("test", "M", 19, "Northeastern University", "India", "Hindi", "test1", "test@1");
drop function if exists student_inserted_id;
delimiter //
Create function student_inserted_id ()
Returns int
Deterministic
reads sql data
Begin
Declare student_id_get int;
set student_id_get = (select max(id) from student);
return student_id_get;
end //
delimiter;


drop function if exists student_exists;
delimiter //
Create function student_exists (student_id_arg int)
Returns int
Deterministic
reads sql data
Begin
declare i int;
select count(*) from student where id = student_id_arg INTO i;
return i;
end //
delimiter ;


drop procedure if exists new_preferences;
delimiter //
create procedure new_preferences(
student_id int, food_preference varchar(15), smoker bit,
 country_preference varchar(30), language_preference varchar(15),
 budget int, gender_preference varchar(5))
begin
insert into preferences values (
id, food_preference, smoker, country_preference, language_preference, budget, gender_preference);
insert into homeseeker values (student_id);
end //
delimiter ;