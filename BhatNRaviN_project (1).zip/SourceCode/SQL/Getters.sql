-- This file contains functions that return the last entered value in the 
-- respective tables to be able to manipulate other tables
-- that use this value as a foreign key.
-- These functions are called during cascading insertions.

-- Get the last inserted student.
drop function if exists student_inserted_id;
delimiter //
Create function student_inserted_id()
Returns int
Deterministic
reads sql data
Begin
Declare student_id_get int;
set student_id_get = (select max(id) from student);
return student_id_get;
end //
delimiter ;

-- select student_inserted_id();

-- Get the last inserted landlord.
drop function if exists landlord_inserted_id;
delimiter //
Create function landlord_inserted_id()
Returns int
Deterministic
reads sql data
Begin
Declare landlord_id_get int;
set landlord_id_get = (select max(id) from landlord);
return landlord_id_get;
end //
delimiter ;


-- Get the last inserted houseid.
drop function if exists house_inserted_id;
delimiter //
Create function house_inserted_id()
Returns int
Deterministic
reads sql data
Begin
Declare house_id_get int;
set house_id_get = (select max(id) from house);
return house_id_get;
end //
delimiter ;

-- Get the last inserted roomID.
drop function if exists room_inserted_id;
delimiter //
Create function room_inserted_id()
Returns int
Deterministic
reads sql data
Begin
Declare room_id_get int;
set room_id_get = (select max(id) from room);
return room_id_get;
end //
delimiter ;

-- Get the last inserted spotid.
drop function if exists spot_inserted_id;
delimiter //
Create function spot_inserted_id()
Returns int
Deterministic
reads sql data
Begin
Declare spot_id_get int;
set spot_id_get = (select max(id) from spot);
return spot_id_get;
end //
delimiter ;

-- Get the last brokerid.
drop function if exists broker_inserted_id;
delimiter //
Create function broker_inserted_id()
Returns int
Deterministic
reads sql data
Begin
Declare broker_id_get int;
set broker_id_get = (select max(id) from broker);
return broker_id_get;
end //
delimiter ;

-- Get the id from the username
drop function if exists get_userid;
delimiter //
Create function get_userid(username_arg VARCHAR(50))
Returns int
Deterministic
reads sql data
Begin
Declare user_id int;
set user_id = (select id from (select distinct id, username
from student
UNION
select distinct id, username
from landlord
UNION
select distinct id, username
from broker) a where username = username_arg);
return user_id;
end //
delimiter ;

select get_userid("test1");
 
select landlord_inserted_id();
select student_inserted_id();
select house_inserted_id();