use roomNest;

-- insert into room table
drop procedure if exists new_spot;
delimiter //
create procedure new_spot(rent int, room_id_arg int)
begin
insert into spot (rent, room_id) values (rent, room_id_arg);
end //
delimiter ;
-- call new_house("Heath St", 2, "Quincy", "MA", 02232, 2, 2, False, 500, 3, 2);

select * from spot;
select * from room;