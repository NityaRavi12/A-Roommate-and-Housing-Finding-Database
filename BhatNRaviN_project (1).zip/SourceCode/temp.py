import pymysql



if __name__ == "__main__":
    # user = input("Enter the username for MySQL: \n")
    # pwd = input("Enter the password for MySQL \n")

    # conn = pymysql.connect(
    #     host='localhost',
    #     user='root',
    #     password='secret',
    #     db='sharkdb',
    # )

    # cur = conn.cursor()
    # conn.close()
    print(globals())
