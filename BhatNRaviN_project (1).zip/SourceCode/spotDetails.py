def createSpot(spots, cursor, conn):
    print("Enter the details of the rooms in the house :\n")
    # Take the details per bedroom
    for i in range(spots):
        print("Enter the details of the rooms in the house :\n")
        print(f"\n{i} spot details have been entered. {spots - i} details yet to be entered\n")
        while True:
            rent = input("What rent would you like to charge for this spot: $")
            try:
                rent = int(rent)
                break
            except:
                print("Please enter an integer amount")
                continue

        # Procedure to get the latest room
        cursor.execute("select room_inserted_id()")
        room_id = cursor.fetchone()[0]

        # Procedure to create a room in a house
        cursor.execute(f"call roomNest.new_spot (\"{rent}\",\"{room_id}\")")
        conn.commit()
    return
