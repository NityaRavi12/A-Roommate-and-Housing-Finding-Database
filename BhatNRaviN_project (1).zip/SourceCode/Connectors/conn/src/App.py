username = input("Enter the MySQL username: ")
pwd = input("Enter the MySQL password")

print(username, pwd, "\n")