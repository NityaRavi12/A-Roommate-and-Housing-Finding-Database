import re
from getpass import getpass

import lib
import studentDetails


def userstatus():
    while True:
        user_status = input(
            "Are you a new user or an existing user?"
            "\n1. New user\n2. Returning user\nChoose an option: \n")
        if user_status != "1" and user_status != "2":
            print("Please enter a valid option.")
        else:
            return user_status


def checkcredentials(username, userpwd, usertype, cursor):
    # Need to call the stored procedure to check if the user exists
    if usertype == 1:
        usertype = 'student'
    elif usertype == 2:
        usertype = 'landlord'
    else:
        usertype = 'broker'

    cursor.execute(
        f"select roomNest.login_details_check(\"{username}\", \"{userpwd}\", \"{usertype}\")")
    found = cursor.fetchone()[0]
    # found = cursor.callfunc('login_details_check', username, userpwd, usertype)
    if found == 0:
        print("Such a user doesn't exist, check your details")
        return 0
    else:
        print("Logging you in...")
        return 1

    # If user exists:
    # return userType
    # Else, ask again


def returninguser(cursor):
    while True:
        username = input("Enter your username: ")
        userpwd = getpass("Password: ")
        # userpwd = input("Enter your password: ")
        try:
            usertype = int(input("Are you a\n1. Student\n2. Landlord\n3. Broker\n"))
        except:
            print("Invalid inputs, try logging in again")
            continue
        foundstatus = checkcredentials(username, userpwd, usertype, cursor)
        if foundstatus == 1:
            # Get the userid of the user
            cursor.execute(f"select get_userid(\"{username}\")")
            userid = cursor.fetchone()[0]
            return userid, usertype
        else:
            print("Incorrect credentials, try again.")


def newuser(cursor, conn):
    name = input("Enter your name: ")
    while True:
        username = input("Create your username: ")
        # Call function to check if username is available
        cursor.execute(
            f"select roomNest.userNameCheck(\"{username}\")")
        found = cursor.fetchone()[0]
        # This username doesn't exist in the DB, so can be assigned to the user
        if found == 0:
            # Allow
            break
        else:
            # Disallow
            print("This username is already taken, please enter another username")
    while True:
        print("What are you here for?")
        usertype = input(
            "1. I am a student\n2. I am a landlord\n3. I am a broker\n")
        if usertype != "1" and usertype != "2" and usertype != "3":
            print("Enter a valid choice")
        else:
            usertype = int(usertype)
            break
    # Only store phone number for landlord and broker
    if int(usertype) == 2 or int(usertype) == 3:
        phregex = lib.re.compile(r'^\d{10}$')
        while True:
            phno = input("Enter your phone number: ")
            if re.match(phregex, phno):
                break
            else:
                print("Please enter a valid 10 digit phone number")

    while True:
        userpwd = getpass("Create a password: ")
        if len(userpwd) < 5:
            print("Please choose a password longer than 5 characters")
            continue
        else:
            break

    if int(usertype) == 2:
        # Insert the landlord to the landlord table
        cursor.execute(
            f"call roomNest.create_new_landlord(\"{name}\",\"{phno}\", \"{username}\", \"{userpwd}\")")
        conn.commit()
        print(cursor.rowcount, "Record inserted successfully into landlord table")
        cursor.execute(
            f"select roomNest.landlord_inserted_id()")
        landlord_id = cursor.fetchone()[0]
        return landlord_id, usertype

    elif int(usertype) == 1:
        # Take the personal details of the student
        studentDetails.enterDetails(username, name, userpwd, cursor, conn)
        # Getting the ID of the student that was just created
        cursor.execute(
            f"select roomNest.student_inserted_id()")
        studentid = cursor.fetchone()[0]
        # Getting the preferences of the newly created student
        # Pass edit flag as 0 since we are not editing but inserting a new record
        studentDetails.enterpreferences(studentid, cursor, 0, conn)
        return studentid, usertype

    else:
        # creating a new broker
        cursor.execute(
            f"call roomNest.create_new_broker(\"{name}\",\"{phno}\", \"{username}\", \"{userpwd}\")")
        conn.commit()
        print(cursor.rowcount, "Record inserted successfully into broker table")
        cursor.execute(
            f"select roomNest.broker_inserted_id()")
        broker_id = cursor.fetchone()[0]
        return broker_id, usertype
