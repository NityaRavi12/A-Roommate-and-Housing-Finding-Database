def chooseStudentMenu():
    print("\n~~~ Welcome to the main menu ~~~\n")
    print("Choose an option: ")
    while True:
        print("1. Find all available housing options")
        print("2. Filter & list housing options that matches your preferences")
        print("3. Edit your housing preferences")
        print("4. Exit")
        choice = input()
        if choice != "1" and choice != "2" and choice != "3" and choice != "4":
            print("Enter a valid choice.\n")
        else:
            return int(choice)


def chooseLandlordMenu():
    while True:
        print("Choose an option: ")
        print("1. Add a house to the website")
        print("2. Remove a house from the website")
        print("3. View all your listed properties")
        print("4. Sign a lease with a student & your broker")
        print("5. Exit the application")
        choice = input()
        if choice != '1' and choice != '2' and choice != '3' and choice != '4' and choice != '5':
            print("Enter a valid choice.\n")
        else:
            return int(choice)


def chooseBrokerMenu():
    while True:
        print("Choose an option: ")
        print("1. Find all leases signed by you")
        print("2. Visualize the data")
        print("3. Exit the application")
        choice = input()
        if choice != "1" and choice != "2" and choice != "3":
            print("Enter a valid choice.\n")
        else:
            return int(choice)
