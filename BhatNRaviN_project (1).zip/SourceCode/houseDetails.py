def createHouse(landlord_id, cursor, conn):
    print("Enter the address of the house :\n")
    street = input("Enter the street name: ")
    unit = input("Enter the unit number: ")
    city = input("Enter the city: ")
    while True:
        state = input("Enter the state: ")
        if len(state) > 2:
            print("Please enter the 2 letter abbreviation")
        else: break
    while True:
        pin = input("Enter the pin: ")
        try:
            pin = int(pin)
            break
        except:
            print("PIN code of a house can only be a number")

    while True:
        floor = input("How many floors does the house have: ")
        try:
            floor = int(floor)
            break
        except:
            print("Floors of a house can only be a number")

    while True:
        bath = input("How many bathrooms does the house have: ")
        try:
            bath = int(bath)
            break
        except:
            print("Number of bathrooms can only be a number")

    while True:
        bed = input("How many bedrooms does your house have: ")
        try:
            bed = int(bed)
            break
        except:
            print("Number of bedrooms can only be a number")

    while True:
        heat = input("Does the house have heating included? (Y/N): ")
        if heat != "Y" and heat != "N":
            print("Please enter Y or N")
        else:
            if heat == "Y":
                heat = True
            else:
                heat = False
            break

    while True:
        area = input("What is the area in sq. ft. of your house? ")
        try:
            int(area)
            break
        except:
            print("Area can only be a number, try again\n")

    while True:
        print("Enter the university closest to this house")
        print("1. Northeastern University")
        print("2. Boston University")
        print("3. MIT")
        proxuni = input()
        if proxuni != "1" and proxuni != "2" and proxuni != "3":
            print("Please choose a valid option")
        else:
            if proxuni == "1":
                proxuni = "Northeastern University"
            elif proxuni == "2":
                proxuni = "Boston University"
            else:
                proxuni = "MIT"
            break

    # cursor.execute(f"select roomNest.landlord_inserted_id()")
    # landlord_id = cursor.fetchone()[0]

    cursor.execute(f"call roomNest.new_house (\"{street}\", \"{unit}\" ,"
                   f" \"{city}\", \"{state}\",{pin},"
                   f" {floor},{bath}, {heat},{area},"
                   f" {bed}, {landlord_id})")
    conn.commit()

    return bed
