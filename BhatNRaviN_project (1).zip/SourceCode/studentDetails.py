def enterDetails(username, name, userpwd, cursor, conn):
    # need to generate studentId
    # Take input for gender
    while True:
        gender = input("Enter your gender (M/F): ")
        if gender != "M" and gender != "F":
            print("Please enter a valid choice (M/F): ")
        else:
            break
    # Take input for age
    while True:
        try:
            age = input("Enter your age: ")
            val = int(age)
            if val <= 0:
                print("Sorry, input must be a positive integer >= 1, try again")
                continue
            break
        except ValueError:
            print("Invalid age, please try again")

    # Take input for university
    while True:
        print("Which university will you be attending?\n")
        print("1. Northeastern University")
        print("2. Boston University")
        print("3. MIT")
        university = input("Enter your choice: ")
        if university != "1" and university != "2" and university != "3":
            print("Please enter one of the above options")
        else:
            if university == "1":
                university = "Northeastern University"
            elif university == "2":
                university = "Boston University"
            else:
                university = "MIT"
            break

    # Take input for country
    print("Which country are you from?\n")
    country = input("Enter your country: ")

    # Take input for language
    language = input("What is your 1 primary spoken language?\n")

    # Call procedure to push into student table
    cursor.execute(
        f"call roomNest.new_student("
        f"\"{name}\",\"{gender}\", {age}, \"{university}\", \"{country}\","
        f" \"{language}\", \"{username}\", \"{userpwd}\")")
    conn.commit()
    print(cursor.rowcount, "Record inserted successfully into student table")


def enterpreferences(studentId, cursor, editflag, conn):
    # Gender preference
    while True:
        print("What is your preference for roomates' genders?")
        print("1. Male\n2. Female\n3. No preference")
        roomatesgender = input("Enter your choice: ")
        if roomatesgender != "1" and roomatesgender != "2" and roomatesgender != "3":
            print("Please enter one of the above options")
        else:
            if roomatesgender == "1":
                roomatesgender = "m"
            elif roomatesgender == "2":
                roomatesgender = "f"
            else:
                roomatesgender = "np"
            break

    # Roommates' country preference
    print("What is your preference for roomates' nationality?")
    roomatecountry = input("Enter the country: ")

    # Roommates' language preference
    print("What is your preference for roomates' language?")
    roomatelanguage = input("Enter the language: ")

    # food preference
    while True:
        print("Do you prefer: \n")
        print("1. Vegetarian roomates")
        print("2. Non vegetarian roomates")
        print("3. No preference")
        food = input("Enter your choice: ")
        if food != "1" and food != "2" and food != "3":
            print("Please enter one of the above options")
        else:
            if food == "1":
                food = "v"
            elif food == "2":
                food = "nv"
            else:
                food = "np"
            break

    # smoking preference
    while True:
        print("Do you prefer: \n")
        print("1. Smoking roomates")
        print("2. Non Smoking roomates")
        smoke = input("Enter your choice: ")
        if smoke != "1" and smoke != "2":
            print("Please enter one of the above options")
        else:
            if smoke == "1":
                smoke = True
            else:
                smoke = False
            break

    # budget preference
    while True:
        print("What is your monthly rent budget?\n")
        try:
            budget = int(input("Enter an amount : $"))
            break
        except:
            print("Please enter a valid number")
            continue
    # Checking if student exists
    # cursor.execute(f"select roomNest.student_exists({studentId})")
    # existing_student = cursor.fetchone()[0]
    # if(existing_student == 0):
    # New student, need to insert prefs
    if editflag == 0:
        cursor.execute(
            f"call roomNest.new_preferences("
            f"{studentId}, \"{food}\", {smoke}, \"{roomatecountry}\", \"{roomatelanguage}\""
            f", \"{budget}\", \"{roomatesgender}\")")
        conn.commit()
        print(cursor.rowcount, "Record inserted successfully into preferences table")
    else:
        # Update existing prefs
        cursor.execute(
            f"call roomNest.update_preferences("
            f"{studentId}, \"{food}\", {smoke}, \"{roomatecountry}\", \"{roomatelanguage}\""
            f", \"{budget}\", \"{roomatesgender}\")")
        conn.commit()
        print(cursor.rowcount, "Record updated successfully into preferences table")
    # check if this student already exits in the DB
    # if exists, then need to call the update procedure
    # if DNE --> New user, create command by using student ID as primary key

    # Call the function to push this data to the preferences table
    # return roomatesgender, food, smoke, budget
