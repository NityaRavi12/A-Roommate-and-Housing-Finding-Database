import visualization


def handleChoice(brokerid, choice, cursor):
    # print("1. Sign a lease with 2 parties")
    # print("2. Find all properties assigned to you")
    if choice == 3:
        print("Thanks for using the application")
        exit(0)
    elif choice == 1:
        # View all leases with the broker
        cursor.execute(f"call roomNest.view_leases({brokerid})")
        results = cursor.fetchall()
        print("Here are the leases you've signed:\n")
        print("~~~~~~~~~~~~~~~~")
        for result in results:
            print(f"Landlord: {result[0]}")
            print(f"Student Name: {result[1]}")
            print(f"Unit: {result[2]}")
            print(f"Street: {result[3]}")
            print(f"House ID: {result[4]}")
            print("~~~~~~~~~~~~~~~~")
        return
    elif choice == 2:
        # Plotting the data
        visualization.plot(cursor)

