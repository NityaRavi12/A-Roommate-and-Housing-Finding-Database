import houseDetails
import roomDetails
import spotDetails


def handleChoice(landlord_id, choice, cursor, conn):
    if choice == 1:
        bed = houseDetails.createHouse(landlord_id, cursor, conn)
        spots = roomDetails.createRoom(bed, cursor, conn)
        spotDetails.createSpot(spots, cursor, conn)
        # Call procedure to insert this house into house table
        # cursor.execute(f"call roomNest.createNewLandlord({name, })")
        print("House successfully added to the database")
        return
    elif choice == 2:
        # Need to make sure the house he is deleting is his own
        cursor.execute(f"call view_houses({landlord_id})")
        results = cursor.fetchall()
        if not results:
            print("Sorry you don't have any houses currently added.\n"
                  "Please add some houses to proceed")
            return
        listOfHouses = []
        print("Here are the houses you can currently take off the market:\n")
        print("~~~~~~~~~~~~~~~~")
        for result in results:
            print(f"ID: {result[0]}")
            print(f"Street: {result[1]}")
            print(f"Unit: {result[2]}")
            listOfHouses.append(result[0])
            print("~~~~~~~~~~~~~~~~")
        print("Which house do you want to take off the market?\nEnter the house ID: ")
        while True:
            house_id = input()
            try:
                house_id = int(house_id)
            except:
                print("Please enter a valid house ID")
            if house_id not in listOfHouses:
                print("You can only delete a house you own.\n"
                      " Please select a house ID from one of the option above")
            else:
                # Call the procedure to drop a house from the database
                cursor.execute(f"call roomNest.delete_house({house_id})")
                conn.commit()
                print("House successfully deleted from the database")
                break
    elif choice == 3:
        cursor.execute(f"call view_houses({landlord_id})")
        results = cursor.fetchall()
        if not results:
            print("Sorry you don't have any houses currently added.\n"
                  "Please add some houses to proceed")
            return
        print("Here are the houses you currently own:\n")
        print("~~~~~~~~~~~~~~~~")
        for result in results:
            print(f"ID: {result[0]}")
            print(f"Street: {result[1]}")
            print(f"Unit: {result[2]}")
            print("~~~~~~~~~~~~~~~~")

        # Call the procedure to select all the houses and room details
        # that are linked to this landlord

    elif choice == 4:
        # Signing the lease with the landlord, broker and the student
        while True:
            student = input("Enter the username of the student: ")
            cursor.execute(f"select userNameCheck_student(\"{student}\")")
            found = cursor.fetchone()[0]
            if found == 0:
                print("This student doesn't exist in the database, please check your spelling")
                continue
            else:
                # Student found
                # Get the student ID
                cursor.execute(f"call roomNest.getStudentId(\"{student}\")")
                studentid = cursor.fetchone()[0]
                # Getting the broker
                broker = input("Enter the username of the broker that got the deal done: ")
                cursor.execute(f"select userNameCheck_broker(\"{broker}\")")
                found = cursor.fetchone()[0]
                if found == 0:
                    print("This broker doesn't exist in the database, please check your spelling")
                    continue
                else:
                    cursor.execute(f"call roomNest.getBrokerId(\"{broker}\")")
                    brokerid = cursor.fetchone()[0]

                    # Getting the house
                    cursor.execute(f"call view_houses({landlord_id})")
                    results = cursor.fetchall()
                    if not results:
                        print("Sorry you don't have any houses currently added.\n"
                              "Please add some houses to proceed")
                        return
                    listOfHouses = []
                    print("Here are the houses you can currently lease:\n")
                    print("~~~~~~~~~~~~~~~~")
                    for result in results:
                        print(f"ID: {result[0]}")
                        print(f"Street: {result[1]}")
                        print(f"Unit: {result[2]}")
                        listOfHouses.append(result[0])
                        print("~~~~~~~~~~~~~~~~")
                    print("Which house do you want to lease?\nEnter the house ID: ")
                    while True:
                        house_id = input()
                        try:
                            house_id = int(house_id)
                        except:
                            print("Please enter a valid house ID")
                        if house_id not in listOfHouses:
                            print("You can only lease out a house you own.\n"
                                  " Please select a house ID from one of the option above")
                        else:
                            break
                    # Create the actual lease
                    cursor.execute(
                        f"call create_lease_table("
                        f"{landlord_id},{brokerid},{studentid},{house_id})")
                    conn.commit()
                    print("Lease created!")
                    return
    else:
        print("Thanks for using the application!")
        exit(0)
