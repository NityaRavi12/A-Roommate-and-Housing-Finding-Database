import matplotlib.pyplot as plt


def plot(cursor):
    cursor.execute("select university, count(name) as students from student group by university")
    result = cursor.fetchall()
    d = dict(result)
    print(d)
    unis = list(d.keys())
    studs = list(d.values())
    unis, studs = zip(*result)
    plt.bar(range(len(d)), studs, tick_label=unis)
    plt.ylim(0, 3)
    plt.xlabel("University")
    plt.ylabel("Number of Students")
    plt.title("Students & Universities")
    plt.show()

# def plot_uni_studs(cursor):
#     cursor.execute("select university, count(name) as students from student group by university")
#     result = cursor.fetchall()
#     d = dict(result)
#     print(d)
#     unis = list(d.keys())
#     studs = list(d.values())
#     unis, studs = zip(*result)
#     plt.bar(range(len(d)), studs, tick_label=unis)
#     plt.ylim(0, 3)
#     plt.xlabel("University")
#     plt.ylabel("Number of Students")
#     plt.title("Students & Universities")
#     plt.show()
